#############################################################################
#
# Author: Michel F. SANNER
#
# Copyright: M. Sanner and TSRI 2015
#
#########################################################################
#
# $Header: /mnt/raid/services/cvs/mglkeyDIST/mglkey/__init__.py,v 1.1.1.1 2016/12/07 23:27:34 sanner Exp $
#
# $Id: __init__.py,v 1.1.1.1 2016/12/07 23:27:34 sanner Exp $
#
from mglkey import MGL_check_key
